<?php
session_start();
include 'checkout_class.php';
$a = new checkout_class();
// print_r($_POST);
$fields['orderId'] = $_SESSION['orderId'];
// echo $fields['orderId'];
$fields['ipAddress'] = '115.96.30.252';
// print_r($fields);exit;
$res = $a->importthankyou($fields);
echo "<pre>";
$fetch = $res->message->data[0];
$fetch1 = $res->message->totalResults;
$fetch2 = $res->message->data[0]->items;
// print_r($fetch); exit;
// $fetch = $fetch1->orderId;
// print_r($fetch);
// echo "</pre>";


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <title>Thank you</title>
</head>

<body>
  <style>
    .thank {
      text-align: center;
      font-size: 60px;
    }
  </style>
  <div class="container">
    <div class="row">
      <div class="col-md-6" style="margin-top:0px;">
        <span class="thank">Shipping Info</span>
        <hr>
        <span><b>First Name:</b> <?php print_r($fetch->orderId); ?></span><br>
        <span><b>Last Name:</b> <?php print_r($fetch->lastName); ?></span><br>
        <span><b>Address:</b> <?php print_r($fetch->address1); ?></span><br>
        <span><b>City:</b> <?php print_r($fetch->city); ?></span><br>
        <span><b>State:</b> <?php print_r($fetch->state); ?></span><br>
        <span><b>Zip Code:</b> <?php print_r($fetch->postalCode); ?></span><br>
        <span><b>Email:</b> <?php print_r($fetch->emailAddress); ?></span><br>
      </div>
      <div class="col-md-6" style="margin-top:0px;">
        <span class="thank">Billing Info</span>
        <hr>
        <span><b>First Name:</b> <?php print_r($fetch->orderId); ?></span><br>
        <span><b>Last Name:</b> <?php print_r($fetch->lastName); ?></span><br>
        <span><b>Address:</b> <?php print_r($fetch->address1); ?></span><br>
        <span><b>City:</b> <?php print_r($fetch->city); ?></span><br>
        <span><b>State:</b> <?php print_r($fetch->state); ?></span><br>
        <span><b>Zip Code:</b> <?php print_r($fetch->postalCode); ?></span><br>
        <span><b>Email:</b> <?php print_r($fetch->emailAddress); ?></span><br>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12" style="margin-top:0px;">
        <table class="table">
          <thead>
            <tr>
              <th>Order Number: <?php print_r($fetch->orderId); ?></th>
              <th></th>
              <th>Order Date: <?php $date = $fetch->orderId; $date = date("M d, Y"); print_r($date); ?></th></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><b>Product</b></td>
              <td><b>Qty.</b></td>
              <td><b>Price</b></td>
            </tr>
            <?php
            $subtotal = $shipping = $total = 0;
            foreach($fetch2 as $fetch2_data=>$val){
              $subtotal += $val->price;
              $shipping += $val->shipping;
            ?>
            <tr>
              <td><b><?php print_r($val->name); ?><b></td>
              <td><?php print_r($val->qty); ?></td>
              <td><?php print_r($fetch->currencySymbol); print_r($val->price); ?></td>
            </tr>
            <?php
            }
            // echo "<br>";
            // echo number_format(($subtotal + $shipping), 2);
            ?>
            <tr>
              <td></td>
              <td>Sub Total:</td>
              <td><?php print_r($fetch->currencySymbol); echo number_format($subtotal, 2); ?></td>
            </tr>
            <tr>
              <td></td>
              <td>Shipping & Handling:</td>
              <td><?php print_r($fetch->currencySymbol); echo number_format($shipping, 2); ?></td>
            </tr>
            <tr>
              <td></td>
              <td><strong>Total:</strong></td>
              <td><strong><?php print_r($fetch->currencySymbol); echo number_format(($subtotal + $shipping), 2) ?></strong></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
</body>

</html>