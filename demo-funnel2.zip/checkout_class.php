<?php
class checkout_class{
    public $api_username = 'actovision';
    public $api_password = '3v1KuGXZvr17';
    // function importlead($fields=array()){
        
    //     $fields2['loginId'] = $this->api_username;
    //     $fields2['password'] =  $this->api_password;

    //     $dataParams = array_merge($fields2,$fields);
    //     // print_r($dataParams);exit(); 

    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    //     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    //     curl_setopt($ch, CURLOPT_URL, "https://api.konnektive.com/leads/import/");
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($ch, CURLOPT_POST, true);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $dataParams);
    //     $raw = curl_exec($ch);
    //     if (empty($raw)) {
    //         $raw = curl_error($ch);
    //     }
    //     curl_close($ch);
    //     $response = json_decode($raw);
    //     return $response;

    // }
    function importorder($fields=array()){
        $fields2['loginId'] = $this->api_username;
        $fields2['password'] =  $this->api_password;

        $dataParams = array_merge($fields2,$fields);
        // print_r($dataParams);exit(); 

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL, "https://api.konnektive.com/order/import/");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataParams);
        $raw = curl_exec($ch);
        if (empty($raw)) {
            $raw = curl_error($ch);
        }
        curl_close($ch);
        $response = json_decode($raw);
        return $response;      
    }
    function importupsell($fields=array()){
        $fields2['loginId'] = $this->api_username;
        $fields2['password'] =  $this->api_password;

        $dataParams = array_merge($fields2,$fields);
        // print_r($dataParams);exit(); 

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL, "https://api.konnektive.com/upsale/import/");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataParams);
        $raw = curl_exec($ch);
        if (empty($raw)) {
            $raw = curl_error($ch);
        }
        curl_close($ch);
        $response = json_decode($raw);
        return $response;    
    }
    function importthankyou($fields=array()){
        $fields2['loginId'] = $this->api_username;
        $fields2['password'] =  $this->api_password;

        $dataParams = array_merge($fields2,$fields);
        // print_r($dataParams);exit(); 

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL, "https://api.konnektive.com/order/query/");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataParams);
        $raw = curl_exec($ch);
        if (empty($raw)) {
            $raw = curl_error($ch);
        }
        curl_close($ch);
        $response = json_decode($raw);
        return $response;   
    }
}
?>