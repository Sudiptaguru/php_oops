<?php 
session_start();
    include 'checkout_class.php';
    $a = new checkout_class();
    // print_r($_POST);
    $fields['orderId'] = $_SESSION['orderId'];
    $fields['campaignId'] = 3;
    $fields['product1_id']=$_POST['product'];
    $fields['paySource'] = $_POST['paySource'];
    $fields['cardNumber'] = $_POST['cardNumber']; 
    $fields['cardMonth'] = $_POST['cardMonth'];
    $fields['cardYear'] = $_POST['cardYear'];
    $fields['cardSecurityCode'] = $_POST['cardSecurityCode']; 
    $fields['ipAddress'] = '115.96.30.251';
    // print_r($fields);exit;
    $res = $a->importorder($fields); 

    //print_r($res); 

    if( $res->result == 'SUCCESS'){ 
        $orderId = $res->message->orderId;
        //$_SESSION['orderId'] = $orderId;
        $resArray['status'] = 1; //success
        $resArray['data']['orderId'] = $orderId;
        echo json_encode($resArray);
    }
    else {
        $resArray['status'] = 0; //error
        $resArray['message'] = $res->message;
        echo json_encode($resArray);
    }
    
?>