<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
  <!-- <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.20/dist/sweetalert2.min.css" rel="stylesheet"> -->
  <title>Home</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4" style="margin-top:40px;">
        <form id="form_data" method="post">
          <div class="form-group">
            <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First name">
          </div>
          <div class="form-group">
            <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last name">
          </div>
          <div class="form-group">
            <input type="text" name="address" id="address" class="form-control" placeholder="Address">
          </div>
          <div class="form-group">
            <input type="text" name="city" id="city" class="form-control" placeholder="City">
          </div>
          <div class="form-group">
            <select class="form-control" id="shippingState" name="shippingState" required="required">
              <option selected="true" disabled="" value="">Choose State</option>
              <option value="AL">Alabama</option>
              <option value="AK">Alaska</option>
              <option value="AZ">Arizona</option>
              <option value="AR">Arkansas</option>
              <option value="CA">California</option>
              <option value="CO">Colorado</option>
              <option value="CT">Connecticut</option>
              <option value="DE">Delaware</option>
              <option value="DC">District of Columbia</option>
              <option value="FL">Florida</option>
              <option value="GA">Georgia</option>
              <option value="HI">Hawaii</option>
              <option value="ID">Idaho</option>
              <option value="IL">Illinois</option>
              <option value="IN">Indiana</option>
              <option value="IA">Iowa</option>
              <option value="KS">Kansas</option>
              <option value="KY">Kentucky</option>
              <option value="LA">Louisiana</option>
              <option value="ME">Maine</option>
              <option value="MD">Maryland</option>
              <option value="MA">Massachusetts</option>
              <option value="MI">Michigan</option>
              <option value="MN">Minnesota</option>
              <option value="MS">Mississippi</option>
              <option value="MO">Missouri</option>
              <option value="MT">Montana</option>
              <option value="NE">Nebraska</option>
              <option value="NV">Nevada</option>
              <option value="NH">New Hampshire</option>
              <option value="NJ">New Jersey</option>
              <option value="NM">New Mexico</option>
              <option value="NY">New York</option>
              <option value="NC">North Carolina</option>
              <option value="ND">North Dakota</option>
              <option value="OH">Ohio</option>
              <option value="OK">Oklahoma</option>
              <option value="OR">Oregon</option>
              <option value="PA">Pennsylvania</option>
              <option value="RI">Rhode Island</option>
              <option value="SC">South Carolina</option>
              <option value="SD">South Dakota</option>
              <option value="TN">Tennessee</option>
              <option value="TX">Texas</option>
              <option value="UT">Utah</option>
              <option value="VT">Vermont</option>
              <option value="VA">Virginia</option>
              <option value="WA">Washington</option>
              <option value="WV">West Virginia</option>
              <option value="WI">Wisconsin</option>
              <option value="WY">Wyoming</option>
              <option value="AS">American Samoa</option>
              <option value="FM">Federated States of Micronesia</option>
              <option value="GU">Guam</option>
              <option value="MP">Northern Mariana Islands</option>
              <option value="PR">Puerto Rico</option>
              <option value="MH">Republic of Marshall Islands</option>
              <option value="VI">Virgin Islands of the U.S.</option>
              <option value="AE">Armed Forces Middle East</option>
              <option value="AA">Armed Forces Americas</option>
              <option value="AP">Armed Forces Pacific</option>
            </select>
          </div>
          <div class="form-group">
            <select class="form-control" id="shippingCountry" name="shippingCountry" required="">
              <option selected="true" disabled="">Choose Country</option>
              <option value="US">United States</option>
              <option value="AU">Australia</option>
              <option value="CA">Canada</option>
              <option value="GB">United Kingdom</option>
            </select>
          </div>
          <div class="form-group">
            <input type="text" name=" zip_code" id="zip_code" class="form-control" placeholder="Zip code">
          </div>
          <div class="form-group">
            <input type="text" name="email" id="email" class="form-control" placeholder="Email Address">
          </div>
          <div class="form-group">
            <input type="text" name="phone" id="phone" class="form-control" placeholder="Phone">
          </div>
          <button type="submit" id="frm_submit" class="btn btn-default" style="width:100%;"> CLICK TO RUSH MY ORDER NOW! </button>
        </form>
      </div>
      <div class="col-md-4"></div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  $("#frm_submit").on( "click", function(e) {
    e.preventDefault();
    // alert("The paragraph was clicked.");
    // var first_name = $("#first_name").val();
    // var last_name = $("#last_name").val();
    // var address = $("#address").val();
    // var city = $("#city").val();
    // var shippingState = $("#shippingState").val();
    // var shippingCountry = $("#shippingCountry").val();
    // var zip_code = $("#zip_code").val();
    // var email = $("#email").val();
    // var phone = $("#phone").val();
    var form_data = $("#form_data").serialize();
    // alert(phone);
    $.ajax({
      url: "import_lead_query.php",
      type: "POST",
      data: form_data,
      dataType: 'json',
      success: function(res) {
        if(res.status == 1) {
          console.log(res.data['orderId']);
          window.location.href = "http://localhost:8000/checkout.php?orderId="+res.data['orderId'];
        }
        else {
          console.log(res.message);
        }
        
      }
    });
  });
</script>

</html>