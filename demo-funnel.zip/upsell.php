<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
<title>Upsell</title>
</head>

<body>
<style>
button
{ width:100%;
height:40px;
font-size:20px;
}

.no-thanks
{ text-align:center;
margin-top:20px;
text-decoration:underline;
}

.no-thanks a
{ font-size:16px;
}




</style>
<div class="container">
<div class="row">
  <div class="col-md-4"></div>
  <div class="col-md-4" style="margin-top:40px;"> <img src="images/bottle.jpg" class="img-responsive center-block" />
    <form id="ups_form" method="post">
      <input type="hidden" name="productId" value="24">
      <button type="button" id="ups_submit">Add To Cart</button>
      <div class="no-thanks"> <a href="#">No thanks </a> </div>
    </form>
  </div>
  <div class="col-md-4"></div>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  $("#ups_submit").on( "click", function(e) {
    e.preventDefault();
    // alert('hbjh');
    var ups_form = $("#ups_form").serialize();
    // alert(ups_form);
    $.ajax({
      url: "import_upsell_query.php",
      type: "POST",
      data: ups_form,
      dataType: 'json',
      success: function(res) {
        if(res.status == 1) {
          console.log(res.data['orderId']);
          window.location.href = "http://localhost:8000/thankyou.php?orderId="+res.data['orderId'];
        }
        else {
          console.log(res.message);
        }
        
      }
    });
  });
</script>
</html>
