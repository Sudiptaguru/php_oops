<?php 
session_start();
    include 'checkout_class.php';
    $a = new checkout_class();
    // print_r($_POST);
    $fields['firstName'] = $_POST['first_name'];
    $fields['lastName'] = $_POST['last_name'];
    $fields['address1'] = $_POST['address'];
    $fields['city'] = $_POST['city'];
    $fields['state'] = $_POST['shippingState'];
    $fields['country'] = $_POST['shippingCountry'];
    $fields['postalCode'] = $_POST['zip_code'];
    $fields['emailAddress'] = $_POST['email'];
    $fields['phoneNumber'] = $_POST['phone'];
    $fields['campaignId'] = 3;
    $fields['ipAddress'] = '115.96.30.251';
    $fields['billShipSame'] = 1;
    // print_r($fields);
    $res = $a->importlead($fields); 

    //print_r($res); 

    if( $res->result == 'SUCCESS'){ 
        $orderId = $res->message->orderId;
        $_SESSION['orderId'] = $orderId;
        $resArray['status'] = 1; //success
        $resArray['data']['orderId'] = $orderId;
        echo json_encode($resArray);
    }
    else {
        $resArray['status'] = 0; //error
        $resArray['message'] = $res->message;
        echo json_encode($resArray);
    }
    
?>