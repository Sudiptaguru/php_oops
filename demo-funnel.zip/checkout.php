<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
  <title>Checkout</title>
</head>

<body>
  <!-- <style>

.form-check
{ display:flex;
border:1px solid #ddd;
padding:20px;
margin-bottom:20px;
}

.pack-price
{ margin-left:20px;
}

.quan
{ margin-right:10px;
}


.form-check input
{ margin-right:10px;
}


</style> -->
  <div class="container">
    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4" style="margin-top:40px;">
        <form id="checkout_data" method="post">
          <input type="hidden" name="paySource" value="CREDITCARD">
          <div class="form-check active">
            <input class="form-check-input" type="radio" name="product" checked value="20" />
            <p class="quan">1</p>
            <p class="mb-0">RB Blueprint</p>
            <p class="pack-price">$46.00</p>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="product" value="21" />
            <p class="quan">2</p>
            <p class="mb-0">RB Blueprint</p>
            <p class="pack-price">$96.00</p>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="product" value="22" />
            <p class="quan">3</p>
            <p class="mb-0">RB Blueprint</p>
            <p class="pack-price">$146.00</p>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="product" value="23" />
            <p class="quan">4</p>
            <p class="mb-0">RB Blueprint</p>
            <p class="pack-price">$246.00</p>
          </div>
          <div class="credit-con">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Credit Card Number</label>
                  <input type="text" name="cardNumber" id="cardNumber" class="form-control" placeholder="Credit Card Number">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="exampleInputEmail1">Card Expiry Month</label>
                  <input type="text" name="cardMonth" id="cardMonth" class="form-control" placeholder="Card expiry month">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="exampleInputEmail1">Card Expiry Year</label>
                  <input type="text" name="cardYear" id="cardYear" class="form-control" placeholder="Card expiry year">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">Cvv</label>
                  <input type="text" name="cardSecurityCode" id="cardSecurityCode" class="form-control" placeholder="Cvv">
                </div>
              </div>
            </div>
          </div>
          <button type="submit" id="chk_submit" class="btn btn-default" style="width:100%;"> PLACE ORDER</button>
        </form>
      </div>
      <div class="col-md-4"></div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  $("#chk_submit").on("click", function(e) {
    e.preventDefault();
    var checkout_data = $("#checkout_data").serialize();
    // alert(checkout_data);
    // alert(phone);
    $.ajax({
      url: "import_order_query.php",
      type: "POST",
      data: checkout_data,
      dataType: 'json',
      success: function(res) {
        if (res.status == 1) {
          console.log(res.data['orderId']);
          window.location.href = "http://localhost:8000/upsell.php?orderId=" + res.data['orderId'];
        } else {
          console.log(res.message);
        }

      }
    });
  });
</script>

</html>